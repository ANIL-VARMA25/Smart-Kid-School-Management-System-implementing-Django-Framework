from django.apps import AppConfig


class StaffsConfig(AppConfig):
    name = "apps.staffs"
